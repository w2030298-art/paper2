# paper2 comparison experiment results package

Generated: 2026-05-20 13:59:00 +08:00

Contents:
- `paper2_full_17_mainline_a_export.zip`: tracked full17 Mainline-A comparison export package.
- `results/`: corrected single-policy 3-user raw JSON, summary CSV, and final algorithm screening decisions.
- `figures/`: corrected single-policy 3-user figures and figure manifest.
- `outputs/stage1/`: PPO/COMA Stage-1 comparison/tuning trial outputs.
- `logs/`: official GPU benchmark logs plus quarantined foreground pipe-failure audit logs.
- `ref/`: regenerated report, decision, artifact inventory, and CL-PPO freeze note.
- `configs/`: benchmark config used for the corrected GPU run.
- `.ai/`: ledger and checkpoint snapshots at packaging time.
