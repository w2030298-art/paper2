# Paper2 Full 17 Mainline-A Benchmark Export

Generated: 2026-05-12T03:40:27.724455+00:00
Run ID: `paper2_full_17_mainline_a`
Purpose: compare all 17 algorithms on the Mainline-A environment and preserve the
data needed to screen algorithms by final performance and convergence trend.

## Included

- `experiments/paper2_full_17_mainline_a/run.json` and `state.json`
- Per-algorithm `result.json`, `checkpoints/train_logs.json`, `stdout.log`, `stderr.log`
- Per-algorithm TensorBoard event files
- `analysis/final_metrics.csv`
- `analysis/convergence_curves.csv`
- `analysis/benchmark_normalized.json`
- `analysis/checkpoint_inventory.csv`
- Mainline-A configs and N0-N3 support result files, when present

## Excluded

PyTorch `.pt` checkpoints are excluded from the archive. Their total raw size is
4061.80 MB, and several individual files are too
large for a 500 MB package. See `analysis/checkpoint_inventory.csv` for the full
inventory and sizes.

## Screening Fields

- Final performance: `analysis/final_metrics.csv` -> `final_reward_mean`,
  `final_latency_mean`, `final_energy_mean`, `final_deadline_miss_rate`
- Convergence: `analysis/convergence_curves.csv` -> one row per algorithm and
  evaluation point
- Raw full metrics: each `result.json` and `train_logs.json`

## Top 5 By Final Reward

- 1. DDPG: final_reward_mean=-4.569996740332901, best_eval_reward_mean=-4.340056437945831, eval_points=49
- 2. SimPO: final_reward_mean=-4.6050916826679344, best_eval_reward_mean=-4.5173583469258745, eval_points=49
- 3. PPO: final_reward_mean=-4.725068947375345, best_eval_reward_mean=-4.756061677526911, eval_points=49
- 4. TD3: final_reward_mean=-5.528161584749514, best_eval_reward_mean=-4.739853434971858, eval_points=49
- 5. GRPO: final_reward_mean=-5.673315070420444, best_eval_reward_mean=-5.294812055603662, eval_points=49
